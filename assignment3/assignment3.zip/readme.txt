File: README
Name: Shivansh Rustagi
CruzID: shrustag
ID Number: 1651034
Class: CMPS 12B
Desc: Table of contents for Assignment 3.

Assignment 3:
    README.txt
    BST.h
    BST.c
    Makefile