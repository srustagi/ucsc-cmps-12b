File: README
Name: Shivansh Rustagi
CruzID: 1651034
Class: CMPS 12B
Desc: Table of contents for Assignment 2.

Assignment 2:
    README.txt
    list.c
    list.h
    listUtil.c
    listUtil.h
    Makefile