File: README
Name: Shivansh Rustagi
CruzID: 1651034
Class: CMPS 12B
Desc: Table of contents for Assignment 1.

Assignment 1:
    README.txt
	list_funcs.c
    list.h
    Makefile