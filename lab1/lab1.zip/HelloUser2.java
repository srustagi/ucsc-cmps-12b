/* ----------------------------------------------------------------------------
 File: HelloUser2.java
 Name: Shivansh Rustagi
 CruzID: shrustag
 Class: CMPS 12M
 Desc: Class which prints out some lyrics from Kal Ho Na Ho. Used in Makefile and Makefile2 to distinguish usage of this file and HelloUser
---------------------------------------------------------------------------- */
class HelloUser2 {
	static public void main(String[] args){
		System.out.println("Har ghadi badal raha hai roop zindagi");
		System.out.println("Chaav hai kahhi hai dhoop zidnagi");
		System.out.println("Har pal yahan jee bhar jiyo");
		System.out.println("Jo hai sama, kal ho na ho");
	}
}