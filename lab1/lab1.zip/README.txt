File: README
Name: Shivansh Rustagi
CruzID: shrustag
Class: CMPS 12M
Desc: Table of contents for Lab 1.

Lab 1:
	HelloUser.java
	HelloUser2.java
	Makefile
	Makefile1
	Makefile2